//---
//Window object
//---
// console.log(window.innerWidth);
console.log(innerHeight);
// console.log(window.innerHeight);
console.log(innerWidth);
// console.log(window.location);
console.log(location);

// console.log(window.location.host);
// console.log(window.history);
// console.log(window.navigator);
// console.log(window.screen);
// console.log(window.alert());
// console.log(window.confirm());
// window.prompt();
// window.open("https://masynctech.com");

console.log(document.body);
