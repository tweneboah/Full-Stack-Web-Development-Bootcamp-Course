//----
//Selecting elements using getElementById
//---
const conferenceTitleEl = document.getElementById("conferenceTitle");
const conferenceDateEl = document.getElementById("conferenceDate");
const locationTitleEl = document.getElementById("locationTitle");
const conferenceLocationEl = document.getElementById("conferenceLocation");
const speakersTitleEl = document.getElementById("speakersTitle");
const speakerListEl = document.getElementById("speakerList");
console.log({
  conferenceTitleEl,
  conferenceTitleEl,
  locationTitleEl,
  conferenceLocationEl,
  speakersTitleEl,
  speakerListEl,
});
