//Get the first product card
const firstProductCardEl = document.querySelector(".product-card");
// console.log(firstProductCardEl);
//Get the highest-rated product
const highestRatingEl = document.querySelector("[data-rating='4.8']");

// Get the first laptop category product
const laptopEl = document.querySelector("[data-category='laptop']");

//selecting an id
const dashboardEl = document.querySelector("#dashboard");
console.log(dashboardEl);
